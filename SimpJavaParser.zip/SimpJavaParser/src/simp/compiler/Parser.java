package simp.compiler;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import simp.compiler.Lexer.Yytoken;

public class Parser {

	// used to ensure there are no returns in main methods and only 1 or 2 in others
	int returnCount = 0;

	Lexer l;
	Lexer.Yytoken symb;

	public Parser(String fname) throws Exception {
		l = new Lexer(new InputStreamReader(new FileInputStream(fname), "Cp1252"));
		lex();
	}

	// gets the next symb and throws error if current symb is unexpected
	private void advance(Lexer.Yytoken tok) throws Exception {
		if (symb == tok)
			symb = l.yylex();
		else
			throw new Exception("Parser error : expected " + tok + " but is " + symb);
	}

	// gets the next symb and throws error if current symb is unexpected

	// obtains the next symb
	public void lex() throws Exception {
		symb = l.yylex();
	}

	private String getStr() {
		return l.yytext();
	}

	public Program Program() throws Exception {
		List<Command> cmds = new ArrayList<Command>();
		// all programs must contain main method, does check for this and fails if
		// remains false
		// ensures only 1 main method exists.
		int mainCount = 0;

		// This add methods with their individual commands to a list until end of file
		// is reached
		while (symb != Lexer.Yytoken.EOF) {

			if (symb == Lexer.Yytoken.METHOD) {
				MethodHeader methodHeader = (MethodHeader) GetMethodHeader();

				mainCount = checkForValidMainMethod(methodHeader, mainCount);

				advance(Lexer.Yytoken.BEGIN);
				List<Command> commandsInMethod = new ArrayList<Command>();

				while (symb != Lexer.Yytoken.ENDMETHOD) {
					commandsInMethod.add(Command());
					checkIfReturn(symb);
				}

				checkForValidReturnCount(methodHeader.name);

				cmds.add(new Method(methodHeader, commandsInMethod));
				advance(Lexer.Yytoken.ENDMETHOD);

			} else {
				throw new Exception("Parser error : expected METHOD but is " + symb);
			}
			returnCount = 0;
		}

		if (!(mainCount == 1))
			throw new Exception("Parser error : Incorrect number of main methods. Should have Exactly 1.");

		Program prog = new Program(cmds);

		return prog;
	}

	private int checkForValidMainMethod(MethodHeader methodHeader, int mainCount) throws Exception {

		if (methodHeader.name.equals("main")) {
			mainCount++;
			if (methodHeader.inputVars.size() > 0)
				throw new Exception("Parser error : Invalid Main Method - Declares variables");
		}

		return mainCount;

	}

	// checks the method has a valid number of returns
	private void checkForValidReturnCount(String name) throws Exception {
		if (name.equals("main")) {
			if (returnCount > 0)
				throw new Exception("Parser error : Invalid Main Method - Contains Return.");
		} else if ((returnCount < 1 || returnCount > 2))
			throw new Exception("Parser error : Invalid Method - Should only contain 1 or 2 returns.");

	}

	private void checkIfReturn(Yytoken symb2) {

		if (symb == Lexer.Yytoken.RETURN)
			returnCount++;

	}

	// Will get the method header with information such as name, input variables and
	// declared variables
	public Command GetMethodHeader() throws Exception {

		List<Var> inputVars = new ArrayList<Var>();
		List<Var> declaredVars = new ArrayList<Var>();

		advance(Lexer.Yytoken.METHOD);
		String name = getStr();
		advance(Lexer.Yytoken.ID);
		advance(Lexer.Yytoken.OPENBRACKET);

		// checks if method contains no input vars
		if (symb.equals(Lexer.Yytoken.CLOSEBRACKET)) {
			advance(Lexer.Yytoken.CLOSEBRACKET);
		} else {

			inputVars.add(new Var(getStr()));
			advance(Lexer.Yytoken.ID);
			inputVars = handeListOfVars(inputVars);
			advance(Lexer.Yytoken.CLOSEBRACKET);

		}

		advance(Lexer.Yytoken.VARS);

		if (symb.equals(Lexer.Yytoken.ID)) {

			declaredVars.add(new Var(getStr()));
			advance(Lexer.Yytoken.ID);
		}

		declaredVars = handeListOfVars(declaredVars);
		return new MethodHeader(name, inputVars, declaredVars);
	}

	// used to get a list of vars separated by a comma
	private List<Var> handeListOfVars(List<Var> inputVars) throws Exception {

		while (symb.equals(Lexer.Yytoken.COMMA)) {
			advance(Lexer.Yytoken.COMMA);
			inputVars.add(new Var(getStr()));
			advance(Lexer.Yytoken.ID);
		}
		return inputVars;
	}

	// handles the commands
	public Command Command() throws Exception {
		if (symb == Lexer.Yytoken.METHOD) {
			return GetMethodHeader();
		} else if (symb == Lexer.Yytoken.ID) {
			return AssignCommand();
		} else if (symb == Lexer.Yytoken.WHILE) {
			return WhileCommand();
		} else if (symb == Lexer.Yytoken.READ) {
			lex();
			return InputCommand();
		} else if (symb == Lexer.Yytoken.WRITE) {
			lex();
			return WriteCommand();
		} else if (symb == Lexer.Yytoken.RETURN) {
			lex();
			return ReturnCommand();
		} else if (symb == Lexer.Yytoken.IF) {
			return IfCommand();
		} else {
			throw new Exception("Parser error: not Command: " + symb);
		}
	}

	// handles assignments e.g x := plus(3,4);
	public Command AssignCommand() throws Exception {

		String var = getStr();
		advance(Lexer.Yytoken.ID);
		advance(Lexer.Yytoken.ASSIGN);
		Exp e = Exp();
		advance(Lexer.Yytoken.SEMI);

		return new AssignCmd(var, e);
	}

	public Command IfCommand() throws Exception {

		advance(Lexer.Yytoken.IF);
		Exp cond = CondExp();
		advance(Lexer.Yytoken.THEN);
		Command cmd1 = Command();

		updateReturnCount(cmd1);

		// handles the case if the IF statement has an ELSE
		if (symb == Lexer.Yytoken.ELSE) {
			lex();
			Command cmd2 = Command();

			updateReturnCount(cmd2);

			advance(Lexer.Yytoken.ENDIF);
			advance(Lexer.Yytoken.SEMI);
			return new IfCmd(cond, cmd1, cmd2);
		} else {
			advance(Lexer.Yytoken.ENDIF);
			advance(Lexer.Yytoken.SEMI);
			return new IfCmd(cond, cmd1);
		}
	}

	private void updateReturnCount(Command cmd1) {

		try {
			ReturnCmd rtrn = (ReturnCmd) cmd1;
			returnCount++;
		} catch (Exception ignore) {
		}
		;

	}

	public Command WhileCommand() throws Exception {
		advance(Lexer.Yytoken.WHILE);
		Exp cond = CondExp();
		advance(Lexer.Yytoken.BEGIN);
		List<Command> cmds = new ArrayList<Command>();

		// adds commands to while block until ENDWHILE is found
		while (symb != Lexer.Yytoken.ENDWHILE) {
			checkIfReturn(symb);
			cmds.add(Command());
		}

		advance(Lexer.Yytoken.ENDWHILE);

		return new WhileCmd(cond, cmds);
	}

	public Command ReturnCommand() throws Exception {
		String name = getStr();
		advance(Lexer.Yytoken.ID);
		advance(Lexer.Yytoken.SEMI);
		return new ReturnCmd(name);
	}

	// handles writing to variables
	public Command WriteCommand() throws Exception {
		Exp e = Exp();
		advance(Lexer.Yytoken.SEMI);
		return new WriteCmd(e);
	}

	// handles reading variables assumes can only read ID as assignment sheet says
	public Command InputCommand() throws Exception {
		String name = getStr();
		advance(Lexer.Yytoken.ID);
		advance(Lexer.Yytoken.SEMI);
		return new InputCmd(name);
	}

	// handles conditional expressions such as is 3 less than 2 less(3,2)
	public Exp CondExp() throws Exception {
		Exp e1;
		Lexer.Yytoken op = symb;
		Set<Lexer.Yytoken> valid = new HashSet<Lexer.Yytoken>();
		valid.add(Lexer.Yytoken.less);
		valid.add(Lexer.Yytoken.lessEq);
		valid.add(Lexer.Yytoken.eq);
		valid.add(Lexer.Yytoken.nEq);
		if (valid.contains(op)) {
			lex();
			advance(Lexer.Yytoken.OPENBRACKET);
			e1 = Exp();
			advance(Lexer.Yytoken.COMMA);
			Exp e2 = Exp();
			advance(Lexer.Yytoken.CLOSEBRACKET);
			return new OpExp(op, e1, e2);
		} else {
			throw new Exception("Not valid operator");
		}
	}

	public Exp Exp() throws Exception {
		Lexer.Yytoken s = symb;
		if (symb == Lexer.Yytoken.times || symb == Lexer.Yytoken.plus || symb == Lexer.Yytoken.minus
				|| symb == Lexer.Yytoken.divide) {

			lex();
			advance(Lexer.Yytoken.OPENBRACKET);
			// I've assumed that it is valid to allow method calls in comparisons such as
			// less(pow(2,1), 4). If it can only contain numbers Exp() would be changed to
			// Base() for e1 and e2
			Exp e1 = Exp();
			advance(Lexer.Yytoken.COMMA);
			Exp e2 = Exp();
			advance(Lexer.Yytoken.CLOSEBRACKET);
			return new OpExp(s, e1, e2);
		} else {
			Exp e1 = Base();

			// handles user created methods that are used during assignments. For example
			// pow(b,a). This would be handled more in backend as it is not a built in
			// operation
			if (symb == Lexer.Yytoken.OPENBRACKET) {
				List<Exp> inputs = new ArrayList<Exp>();
				IdentExp e5 = (IdentExp) e1;
				lex();

				if (!(symb == Lexer.Yytoken.CLOSEBRACKET)) {
					inputs.add(Exp());
				}

				while (!(symb == Lexer.Yytoken.CLOSEBRACKET)) {
					advance(Lexer.Yytoken.COMMA);
					inputs.add(Exp());
				}

				advance(Lexer.Yytoken.CLOSEBRACKET);
				return new UserOp(e5.v, inputs);
			}
			return e1;
		}
	}

	public Exp Base() throws Exception {
		String v = null;
		switch (symb) {
		case ID:
			v = getStr();
			lex();
			return new IdentExp(v);
		case INT:
			v = getStr();
			lex();
			return new NumberExp(Integer.parseInt(v));
		default:
			throw new Exception("Parsing : base: int/ident/( expected but " + symb + " found");
		}
	}

	public void lextest() throws IOException {
		Lexer.Yytoken tok = l.yylex();
		while (tok != Lexer.Yytoken.EOF) {
			System.out.println(l.yytext());
			tok = l.yylex();
		}
	}

}
