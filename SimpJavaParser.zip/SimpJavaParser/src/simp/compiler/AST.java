package simp.compiler;

import java.util.List;

interface ASTVisitor {
	void visit(Program prog) throws Exception;
	void visit(WriteCmd cmd) throws Exception;
	void visit(InputCmd cmd) throws Exception;
	void visit(WhileCmd cmd) throws Exception;
	void visit(IfCmd cmd) throws Exception;
	void visit(AssignCmd cmd) throws Exception;
	void visit(IdentExp e) throws Exception;
	void visit(NumberExp e) throws Exception;
	void visit(OpExp e) throws Exception;
	void visit(Var var) throws Exception;
	void visit(MethodHeader methodHeader) throws Exception;
	void visit(Method method) throws Exception;
	void visit(ReturnCmd returnCmd) throws Exception;
	void visit(UserOp userOp) throws Exception;
}

interface ASTElement {
	void accept(ASTVisitor visitor) throws Exception;
}

abstract class Exp implements ASTElement {
}

class IdentExp extends Exp implements ASTElement {
	String v;

	public IdentExp(String v) {
		this.v = v;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class NumberExp extends Exp implements ASTElement {
	int n;

	public NumberExp(int n) {
		this.n = n;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class OpExp extends Exp implements ASTElement {
	Lexer.Yytoken op;
	Exp left;
	Exp right;

	public OpExp(Lexer.Yytoken op, Exp left, Exp right) {
		this.op = op;
		this.left = left;
		this.right = right;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}

}

class UserOp extends Exp implements ASTElement {
	String op;
	List<Exp> inputs;

	public UserOp(String op, List<Exp> inputs) {
		this.op = op;
		this.inputs = inputs;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}

}

class Var implements ASTElement {

	String var;

	public Var(String v) {
		var = v;

	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}

}

abstract class Command implements ASTElement {
}

class AssignCmd extends Command implements ASTElement {
	String var;
	Exp e;

	public AssignCmd(String v, Exp e) {
		this.var = v;
		this.e = e;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class IfCmd extends Command implements ASTElement {
	Exp cond;
	Command cmd1;
	Command cmd2;

	public IfCmd(Exp cond, Command cmd1) {
		this.cond = cond;
		this.cmd1 = cmd1;
		this.cmd2 = null;
	}

	public IfCmd(Exp cond, Command cmd1, Command cmd2) {
		this.cond = cond;
		this.cmd1 = cmd1;
		this.cmd2 = cmd2;
	}

	public boolean hasElse() {
		return cmd2 != null;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class Method extends Command implements ASTElement {
	Command methodHeader;
	List<Command> commands;

	public Method(Command methodHeader, List<Command> commands) {
		this.methodHeader = methodHeader;
		this.commands = commands;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class MethodHeader extends Command implements ASTElement {
	String name;
	List<Var> inputVars;
	List<Var> declareVars;

	public MethodHeader(String name, List<Var> inputVars, List<Var> declaredVars) {
		this.name = name;
		this.inputVars = inputVars;
		this.declareVars = declaredVars;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class WhileCmd extends Command implements ASTElement {
	Exp cond;
	List<Command> commands = null;

	public WhileCmd(Exp cond, List<Command> commands) {
		this.cond = cond;
		this.commands = commands;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class ReturnCmd extends Command implements ASTElement {
	String id;

	public ReturnCmd(String id) {
		this.id = id;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class InputCmd extends Command implements ASTElement {
	String id;

	public InputCmd(String id) {
		this.id = id;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class WriteCmd extends Command implements ASTElement {
	Exp exp;

	public WriteCmd(Exp exp) {
		this.exp = exp;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}

class Program implements ASTElement {

	List<Command> cmds;

	public Program(List<Command> cmds) {
		this.cmds = cmds;
	}

	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}
