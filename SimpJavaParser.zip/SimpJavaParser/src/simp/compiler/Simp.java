package simp.compiler;

public class Simp {

	public static void main(String[] args) throws Exception{
		String fname = "myprogram.txt";
		Parser p = new Parser(fname);
		p.lextest();
		p = new Parser(fname);
		Program prog = p.Program();
		// Pretty printing of program
		ASTPrinter ast = new ASTPrinter();
		prog.accept(ast);

	}
}
