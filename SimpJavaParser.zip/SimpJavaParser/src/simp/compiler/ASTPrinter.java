package simp.compiler;

public class ASTPrinter implements ASTVisitor {

	int indent;

	private void printIndent() {
		for (int i = 0; i < indent; i++)
			System.out.print(" ");
	}

	public ASTPrinter() {
		indent = 0;
	}

	@Override
	public void visit(Program prog) throws Exception {
		indent = 0;

		for (Command c : prog.cmds) {
			c.accept(this);
		}

	}

	@Override
	public void visit(MethodHeader cmd) throws Exception {
		printIndent();
		System.out.print("method " + cmd.name + "(");

		String test = "";

		for (int i = 0; i < cmd.inputVars.size() - 1; i++) {
			test += cmd.inputVars.get(i).var + ", ";
		}

		if (cmd.inputVars.size() > 0) {
			test += cmd.inputVars.get(cmd.inputVars.size() - 1).var;
		}

		System.out.print(test + ") vars ");
		test = "";

		for (int i = 0; i < cmd.declareVars.size() - 1; i++) {
			test += cmd.declareVars.get(i).var + ", ";
		}

		if (cmd.declareVars.size() > 0) {
			test += cmd.declareVars.get(cmd.declareVars.size() - 1).var;
		}

		indent = indent + 2;

		System.out.println(test);

	}

	@Override
	public void visit(WriteCmd cmd) throws Exception {
		printIndent();
		System.out.print("write ");
		cmd.exp.accept(this);
		System.out.println(";");

	}

	@Override
	public void visit(InputCmd cmd) throws Exception {
		printIndent();
		System.out.print("read " + cmd.id + ";");
	}

	@Override
	public void visit(WhileCmd cmd) throws Exception {
		printIndent();
		System.out.print("while ");
		cmd.cond.accept(this);
		System.out.println();
		printIndent();
		System.out.println("begin");
		indent = indent + 2;
		for (int i = 0; i < cmd.commands.size(); i++) {

			cmd.commands.get(i).accept(this);

		}
		indent = indent - 2;
		printIndent();
		System.out.println("endwhile");

	}

	@Override
	public void visit(IfCmd cmd) throws Exception {
		printIndent();
		System.out.print("if ");
		cmd.cond.accept(this);
		System.out.println(" then");
		indent = indent + 2;
		cmd.cmd1.accept(this);
		indent = indent - 2;
		if (cmd.cmd2 != null) {
			printIndent();
			System.out.println("else");
			indent = indent + 2;
			cmd.cmd2.accept(this);
			indent = indent - 2;
		}
	}

	@Override
	public void visit(AssignCmd cmd) throws Exception {
		printIndent();
		System.out.print(cmd.var + " := ");
		cmd.e.accept(this);
		System.out.println(";");
	}

	@Override
	public void visit(IdentExp e) throws Exception {
		System.out.print(e.v);
	}

	@Override
	public void visit(NumberExp e) throws Exception {
		System.out.print(e.n);
	}

	@Override
	public void visit(OpExp e) throws Exception {
		System.out.print(e.op + "(");
		e.left.accept(this);
		System.out.print(", ");
		e.right.accept(this);
		System.out.print(")");
	}

	@Override
	public void visit(Var v) throws Exception {
		printIndent();
		System.out.println("VAR " + v.var);

	}

	@Override
	public void visit(Method method) throws Exception {

		System.out.println();

		method.methodHeader.accept(this);

		for (int i = 0; i < method.commands.size(); i++) {
			method.commands.get(i).accept(this);

		}

		indent = indent - 2;
		System.out.println("endmethod");

	}

	@Override
	public void visit(ReturnCmd returnCmd) throws Exception {

		printIndent();
		System.out.println("return " + returnCmd.id);

	}

	@Override
	public void visit(UserOp userOp) throws Exception {
		System.out.print(userOp.op + "(");
		for (int i = 0; i < userOp.inputs.size() - 1; i++) {
			userOp.inputs.get(i).accept(this);
			System.out.print(", ");
		}

		if (userOp.inputs.size() > 0) {
			userOp.inputs.get(userOp.inputs.size() - 1).accept(this);
		}

		System.out.print(")");

	}

}
